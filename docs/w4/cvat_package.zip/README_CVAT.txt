Tap chuan E1 (issue #24). Ve 1 hop sat vat the bay (lop: object) tren MOI anh.
Quy tac: docs/w4/cvat_gold_guide.md. Khong mo bat ky file nhan goc nao cua dataset khi ve.
Xuat ket qua: Export task -> 'YOLO 1.1' -> gui file zip cho Quang (hoac commit vao results/W04/cvat_gold/).
